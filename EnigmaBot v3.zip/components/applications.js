const SimpleDiscord = require('simple-discord-modules');
const config = require('../config.json');
const build = require('../build.json');
const messages = require('../JSON/messages.json')[config.lang];

module.exports = (client, instance) => {
	let logChannel = client.channels.cache.get(config[build.type].channels.log);
	client.on('interactionCreate', async (interaction) => {
		let applicantRole = interaction.guild.roles.cache.get(config[build.type].roles.applicant);
		if (!interaction.isButton()) return;
		if (interaction.customId == 'applicationInfoAccept') {
			if (!interaction.member.roles.cache.has(applicantRole.id)) {
				interaction.member.roles.add(applicantRole);
				interaction.reply({
					content: `You have accepted our applications requirements!\nYou may now submit your application in <#${
						config[build.type].channels.applications
					}>!`,
					ephemeral: true,
				});

				let logMessage = SimpleDiscord.embedMaker({
					author: '✅  Application Acceptance',
					authorImage: interaction.member.user.avatarURL(),
					description: `<@${interaction.member.user.id}> accepted the application requirements.`,
					color: config.color,
					footer: `User ID: ${interaction.member.user.id}`,
					timestamp: true,
				});
				logChannel.send({ embeds: [logMessage] });
			} else {
				interaction.reply({
					content: 'You have already accepted the application requirements.',
					ephemeral: true,
				});
			}
		}
		return;
	});

	client.on('messageCreate', (message) => {
		if (message.author.bot) return;
		if (message.channel.id == config[build.type].channels.applications) {
			if (
				!message.content.toLowerCase().includes('[name]') ||
				!message.content.toLowerCase().includes('[age]') ||
				!message.content.toLowerCase().includes('[timezone]') ||
				!message.content.toLowerCase().includes('[ign]') ||
				!message.content.toLowerCase().includes('[links]') ||
				!message.content.toLowerCase().includes('[reason]')
			) {
				message.delete();
				let reply = SimpleDiscord.embedMaker({
					title: 'Uh Oh.',
					description: `Looks like your application was missing something! Be sure to include the following in your application.\n\`\`\`\n[Name]\n[Age]\n[Timezone]\n[IGN]\n[Links]\n[Reason]\n\`\`\`\n**Here\'s your application:**\`\`\`${message.content}\`\`\``,
					color: config.color,
				});
				message.author.send({ embeds: [reply] });
				return;
			}
		}
	});
};

module.exports.config = {
	displayName: 'Applicant Manager',
	dbName: 'NONE',
};
