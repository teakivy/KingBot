const SimpleDiscord = require('simple-discord-modules');
const config = require('../config.json');
const fs = require('fs');
const build = require('../build.json');
const xp = require('../JSON/data/xp');
const messages = require('../JSON/messages.json')[config.lang];
const { MessageActionRow, MessageButton, MessageSelectMenu } = require('discord.js');

module.exports = (client, instance) => {
	client.on('messageCreate', async (message) => {
		const author = message.author;

		if (xp[author.id]) {
			xp[author.id].xp = xp[author.id].xp + getMessageXP(author);
			xp[author.id].lastXP = Date.now();

			fs.writeFileSync('././JSON/data/xp.json', JSON.stringify(xp, null, '\t'));

			// console.log(xp[author.id].xp);
		} else {
			xp[author.id] = {
				xp: getRandomInt(16) + 15,
				level: 0,
				tier: 0,
				lastXP: Date.now(),
			};
			fs.writeFileSync('././JSON/data/xp.json', JSON.stringify(xp, null, '\t'));
		}

		// Delete Pin message after locking a channel
		if (message.type == 'CHANNEL_PINNED_MESSAGE' && message.author.id == client.user.id) {
			message.delete({ timeout: 100 });
		}

		// Ty Np
		if (message.content.toLowerCase() == 'ty') {
			if (Math.floor(Math.random() * 2) == 1) return;
			message.channel.send(messages.responses.ty);
		}

		if (message.content.includes('https://www.youtube.com/watch?v=dQw4w9WgXcQ')) {
			message.react('😏');
		}

		if (message.content.includes(`<@!${client.user.id}>`)) {
			let genHelloResponse = Math.floor(Math.random() * messages.responses.hello.length);
			message.channel.send(
				messages.responses.hello[genHelloResponse].replace('${author_mention}', `<@${message.author.id}>`)
			);
		}

		if (message.channel.type == 'dm' && !message.author.bot) {
			let genDMResponse = Math.floor(Math.random() * messages.responses.dm.length);
			message.channel.send(
				messages.responses.dm[genDMResponse].replace('${author_mention}', `<@${message.author.id}>`)
			);
		}

		if (message.content == '!!selectMenuSend' && message.author.tag == 'TeakIvy#0659') {
			const row = new MessageActionRow().addComponents(
				new MessageSelectMenu()
					.setCustomId('pronoun_select')
					.setPlaceholder('Select your Pronouns...')
					.setMinValues(0)
					.setMaxValues(1)
					.addOptions([
						{
							label: 'He/Him',
							value: 'he_pronoun_role',
							emoji: '🙋‍♂️',
						},
						{
							label: 'She/Her',
							value: 'she_pronoun_role',
							emoji: '🙋‍♀️',
						},
						{
							label: 'They/Them',
							value: 'they_pronoun_role',
							emoji: '🙋',
						},
						{
							label: 'Ask my Pronouns',
							value: 'ask_pronoun_role',
							emoji: '❓',
						},
					])
			);

			let reply = SimpleDiscord.embedMaker({
				title: '🚶 Pronoun Roles',
				description:
					'Select which pronouns you prefer to go by:\n\n🙋‍♂️ **He/Him**\n🙋‍♀️ **She/Her**\n🙋 **They/Them**\n❓ **Ask my Pronouns**',
				color: config.color,
			});

			message.channel.send({ embeds: [reply], components: [row] });
		}

		if (message.content == '!!selectMenuSend' && message.author.tag == 'TeakIvy#0659') {
			const row = new MessageActionRow().addComponents(
				new MessageSelectMenu()
					.setCustomId('notification_select')
					.setPlaceholder('Choose your Notifications...')
					.setMinValues(0)
					.setMaxValues(3)
					.addOptions([
						{
							label: 'YouTube',
							value: 'youtube_notification_role',
							emoji: {
								name: 'youtube',
								id: '889303093609644104',
							},
						},
						{
							label: 'Twitch',
							value: 'twitch_notification_role',
							emoji: {
								name: 'twitch',
								id: '889303068066349087',
							},
						},
						{
							label: 'Twitter',
							value: 'twitter_notification_role',
							emoji: {
								name: 'twitter',
								id: '889303050207002666',
							},
						},
					])
			);

			let reply = SimpleDiscord.embedMaker({
				title: '🔔 Notification Roles',
				description:
					'Select which Notifications you would like to receive:\n\n<:youtube:889303093609644104> **YouTube**\n<:twitch:889303068066349087> **Twitch**\n<:twitter:889303050207002666> **Twitter**',
				color: config.color,
			});

			message.channel.send({ embeds: [reply], components: [row] });
		}

		if (message.content == '!!updateNotificationSquad' && message.author.tag == 'TeakIvy#0659') {
			let notificationRole = message.guild.roles.cache.get(config[build.type].roles.notificationSquad);
			let youtubeRole = message.guild.roles.cache.get(config[build.type].roles.youtubeNotifications);
			let twitchRole = message.guild.roles.cache.get(config[build.type].roles.twitchNotifications);
			message.guild.members.cache.each((user) => {
				if (user.roles.cache.has(notificationRole.id)) {
					user.roles.remove(notificationRole);

					user.roles.add(youtubeRole);
					user.roles.add(twitchRole);
				}
			});
		}
		if (message.content == '!!applicationMessage' && message.author.tag == 'TeakIvy#0659') {
			message.delete();
			let embed = SimpleDiscord.embedMaker({
				title: 'Application Info',
				description: `With Season 3 well on its way, we feel it is finally time to re-open our Applications!\nTo submit an application, read through this, then post your application in <#${
					config[build.type].channels.applications
				}> !\n᲼`,
				fields: [
					{
						name: '👮‍♂️ Requirements',
						value:
							'> **-** You must be over the age of 18\n> **-** You must create Minecraft content on a regular basis\n᲼',
					},
					{
						name: '📙 Information',
						value:
							'> We run our server as a democracy, and as such everyone is voted on by our members. To be accepted into the server, you will need to reach our join quota.\n> \n> **-** 75% Yes on your vote\n> **-** 50% Of all possible votes cast\n᲼',
					},
					{
						name: '📝 Application Format',
						value:
							"> Please form your application using the following format, or you will not be able to submit your application.\n> \n> **[Name]** *Your Name*\n> **[Age]** *How old you are (doesn't have to be exact)*\n> **[Timezone]** *Your time zone*\n> **[IGN]** *Your Minecraft IGN*\n> **[Links]** *Any channel links you would like to share*\n> **[Reason]** *Why you want to join*\n> **[Extra]** *Any extra information you want to include*\n᲼",
					},
					{
						name: '❓ FAQ',
						value:
							'**Why 18 years old?**\n> We have an age requirement of 18 in order to comply with youtube and COPPA.\n\n**Do I have to make videos on the server, or can I just stream?**\n> You may stream, but be aware, as you have more uncut content to review, you may get judged a bit harder than those who create videos.\n\n**How long do application votes last?**\n> Your vote will be active for 72 hours to allow as many people to vote as possible.\n\n**How do I know if i was accepted?**\n> You will receive a DM from one of our moderators after your vote has closed.\n᲼',
					},
				],
				footer: 'Press the ✅ below to gain access to the applications channel!',
				footerImage: client.user.avatarURL(),
				thumbnail: client.user.avatarURL(),
				color: config.color,
			});

			let row = new MessageActionRow().addComponents(
				new MessageButton().setCustomId('applicationInfoAccept').setEmoji('✔️').setStyle('SUCCESS')
			);

			message.channel.send({ embeds: [embed], components: [row] });
		}
	});
};

const getMessageXP = (author) => {
	if (xp[author.id].lastXP + 30 * 1000 > Date.now()) return 0;
	return getRandomInt(16) + 15;
};

function getRandomInt(max) {
	return Math.floor(Math.random() * max);
}

module.exports.config = {
	displayName: 'Message Handler',
	dbName: 'NONE',
};
