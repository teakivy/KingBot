const SimpleDiscord = require('simple-discord-modules');
const config = require('../config.json');
const build = require('../build.json');
const messages = require('../JSON/messages.json')[config.lang];

module.exports = (client, instance) => {
	let logChannel = client.channels.cache.get(config[build.type].channels.log);
	client.on('interactionCreate', async (interaction) => {
		let notificationRole = interaction.guild.roles.cache.get(config[build.type].roles.notificationSquad);
		if (!interaction.isButton()) return;
		if (interaction.customId == 'notificationSquadButton') {
			if (interaction.member.roles.cache.has(notificationRole.id)) {
				interaction.member.roles.remove(notificationRole);
				interaction.reply({
					content: 'You have unsubscribed to all notifications!\nPress the 🔔 to subscribe again.',
					ephemeral: true,
				});

				let logMessage = SimpleDiscord.embedMaker({
					author: '🔔  Notification Squad',
					authorImage: interaction.member.user.avatarURL(),
					description: `<@${interaction.member.user.id}> unsubscribed to the Notification Squad.`,
					color: config.color,
					footer: `User ID: ${interaction.member.user.id}`,
					timestamp: true,
				});
				logChannel.send({ embeds: [logMessage] });
			} else {
				interaction.member.roles.add(notificationRole);
				interaction.reply({
					content: 'You have subscribed to all notifications!\nPress the 🔔 again to unsubscribe.',
					ephemeral: true,
				});

				let logMessage = SimpleDiscord.embedMaker({
					author: '🔔  Notification Squad',
					authorImage: interaction.member.user.avatarURL(),
					description: `<@${interaction.member.user.id}> subscribed to the Notification Squad.`,
					color: config.color,
					footer: `User ID: ${interaction.member.user.id}`,
					timestamp: true,
				});
				logChannel.send({ embeds: [logMessage] });
			}
			return;
		}
		return;
	});
};

module.exports.config = {
	displayName: 'Notification Squad',
	dbName: 'NONE',
};
