const SimpleDiscord = require('simple-discord-modules');
const config = require('../config.json');
const build = require('../build.json');
const messages = require('../JSON/messages.json')[config.lang];

module.exports = (client, instance) => {
	client.on('guildMemberRemove', async (member) => {
		client.channels.cache
			.get(config[build.type].channels.leave)
			.send(messages.responses.leave.replace('${user_tag}', member.user.tag));
	});
};

module.exports.config = {
	displayName: 'Leave Handler',
	dbName: 'NONE',
};
