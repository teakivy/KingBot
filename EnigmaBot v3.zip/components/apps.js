const SimpleDiscord = require('simple-discord-modules');

module.exports = (client, instance) => {
	client.on('interactionCreate', async (interaction) => {
		if (!interaction.isContextMenu()) return;
		if (interaction.commandName == 'Report') {
			interaction.reply({
				embeds: [SimpleDiscord.embedMaker({ title: '📋  Message Reported', color: '#eb7e10' })],
				ephemeral: true,
			});
			let msg = await interaction.channel.messages.fetch(interaction.targetId);

			let reply = SimpleDiscord.embedMaker({
				author: msg.author.tag,
				description: msg.content,
				color: '#eb7e10',
				authorLink: msg.url,
				authorImage: msg.author.avatarURL(),
				footer: `Reported by: ${interaction.user.tag}`,
				timestamp: true,
			});

			client.channels.cache.get('<reports channel id>').send({ embeds: [reply] });

			console.log(
				`\nMessage Reported: \nReported By: ${interaction.member.user.tag}\nUser: ${msg.author.tag}\nContent: ${msg.content}`
			);
		}
	});
};

module.exports.config = {
	displayName: 'Report Messages',
	dbName: 'NONE',
};
