const SimpleDiscord = require('simple-discord-modules');
const config = require('../config.json');
const messages = require('../JSON/messages.json')[config.lang];

module.exports = {
	name: 'enigma',
	category: 'Fun & Games',
	slash: true,
	description: 'Enigma SMP!',
	callback: ({ interaction }) => {
		let reply = messages.commands.enigma.response;

		interaction.reply({ content: reply });
	},
};
